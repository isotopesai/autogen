# AutoGen Extensions

- [Documentation](https://microsoft.github.io/autogen/stable/user-guide/extensions-user-guide/index.html)

AutoGen is designed to be extensible. The `autogen-ext` package contains many different component implementations maintained by the AutoGen project. However, we strongly encourage others to build their own components and publish them as part of the ecosytem.
